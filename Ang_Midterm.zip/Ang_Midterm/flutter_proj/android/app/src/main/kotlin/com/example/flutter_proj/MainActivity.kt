package com.example.flutter_proj

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
